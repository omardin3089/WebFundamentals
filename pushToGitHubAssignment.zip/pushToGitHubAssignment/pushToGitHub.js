//Practice Push to github

console.log("hello world");